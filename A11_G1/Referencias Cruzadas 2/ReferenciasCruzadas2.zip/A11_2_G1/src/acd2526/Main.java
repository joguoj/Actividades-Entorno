package acd2526;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el número de casos de prueba: ");
        if (sc.hasNextInt()) {
            int casos = sc.nextInt();
            
            for (int i = 0; i < casos; i++) {
                System.out.println("\n--- Caso " + (i + 1) + " ---");
                System.out.print("Introduce la versión antigua (ejemplo 1.2.3): ");
                String version1 = sc.next();
                
                System.out.print("Introduce la versión nueva a comprobar (ejemplo 1.3.0): ");
                String version2 = sc.next();

                String[] partes1 = version1.split("\\.");
                String[] partes2 = version2.split("\\.");

                if (partes1.length < 3 || partes2.length < 3) {
                    System.out.println("¡Error! Las versiones deben tener 3 números (Mayor.Menor.Parche). Inténtalo de nuevo.");
                    i--; 
                    continue; 
                }

                int may1 = Integer.parseInt(partes1[0]);
                int men1 = Integer.parseInt(partes1[1]);
                int par1 = Integer.parseInt(partes1[2]);

                int may2 = Integer.parseInt(partes2[0]);
                int men2 = Integer.parseInt(partes2[1]);
                int par2 = Integer.parseInt(partes2[2]);

                boolean esSiguiente = false;

                if (may2 == may1 + 1 && men2 == 0 && par2 == 0) {
                    esSiguiente = true;
                } else if (may2 == may1 && men2 == men1 + 1 && par2 == 0) {
                    esSiguiente = true;
                } else if (may2 == may1 && men2 == men1 && par2 == par1 + 1) {
                    esSiguiente = true;
                }

                System.out.print("¿Es la versión correcta?: ");
                if (esSiguiente) {
                    System.out.println("SI");
                } else {
                    System.out.println("NO");
                }
            }
        }
        
        sc.close();
    }
}
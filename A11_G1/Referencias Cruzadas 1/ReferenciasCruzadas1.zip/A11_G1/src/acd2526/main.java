package acd2526;

import java.util.Scanner;
import java.util.TreeMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        
        String textoDePrueba = 
            "4\n" +
            "Guerra tenia una parra y Parra tenia una perra\n" +
            "la perra de Parra rompio la parra de Guerra\n" +
            "y Guerra aporreo con la porra a la perra\n" +
            "Si la perra de Parra no hubiera roto la parra de Guerra este no hubiera aporreado con la porra a la perra de Parra\n" +
            "0\n";
        
        Scanner sc = new Scanner(textoDePrueba);

        while (sc.hasNextInt()) {
            int n = sc.nextInt();
            
            if (n == 0) {
                System.out.println("\n¡Fin del programa!");
                break;
            }
            
            sc.nextLine();

            TreeMap<String, ArrayList<Integer>> referencias = new TreeMap<>();

            for (int i = 1; i <= n; i++) {
                String linea = sc.nextLine();
                System.out.println(linea);
                
                String[] palabras = linea.split(" ");
                
                for (String palabra : palabras) {
                    palabra = palabra.toLowerCase();
                    
                    if (palabra.length() > 2) {
                        
                        if (!referencias.containsKey(palabra)) {
                            referencias.put(palabra, new ArrayList<>());
                        }
                        
                        ArrayList<Integer> lineas = referencias.get(palabra);
                        
                        if (lineas.isEmpty() || lineas.get(lineas.size() - 1) != i) {
                            lineas.add(i);
                        }
                    }
                }
            }
            System.out.print("\n");

            for (String palabra : referencias.keySet()) {
            	
                System.out.print(palabra);
                
                for (int numeroLinea : referencias.get(palabra)) {
                    System.out.print(" " + numeroLinea);
                }
                System.out.println();
            }
            System.out.println("----");
            System.out.println();
        }
        
        sc.close();
    }
}
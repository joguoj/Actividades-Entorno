package A10;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el primer número romano:");
		String num1 = sc.nextLine();
		System.out.println("Introduce el segundo número romano:");
		String num2 = sc.nextLine();
		//System.out.println(TraductorRomano(num));
		
		sc.close();
		
		try {
			ComparadorRomano(num1, num2);
		} catch (IllegalArgumentException e) {
			
			System.out.println("El número romano es inválido.");
		}
		
	}
	
	public static boolean compResta(char c1, char c2) {
		if (c1 == 'I' && (c2 == 'V' || c2 == 'X')) return true;
		if (c1 == 'X' && (c2 == 'L' || c2 == 'C')) return true;
		if (c1 == 'C' && (c2 == 'D' || c2 == 'M')) return true;
		
		return false;
	}
	
	public static int TraductorRomano(String num) {
		Map<Character, Integer> dicc = new HashMap<Character, Integer>();
		dicc.put('I', 1);
		dicc.put('V', 5);
		dicc.put('X', 10);
		dicc.put('L', 50);
		dicc.put('C', 100);
		dicc.put('D', 500);
		dicc.put('M', 1000);
		
		int valtotal = 0;
		
		if (num.contains("IIII") || num.contains("XXXX") || num.contains("CCCC") 
			|| num.contains("DDDD") || num.contains("VV") || num.contains("LL")
			|| num.contains("DD")) {
			throw new IllegalArgumentException("Número inválido.");
		}
		
		for (int i = 0; i < num.length(); i++) {
			int val1 = dicc.get(num.charAt(i));
			
			if (i + 1 < num.length()) {
				int val2 = dicc.get(num.charAt(i+1));
				
				if (val1 < val2) {
					if (!compResta(num.charAt(i), num.charAt(i+1))) {
						throw new IllegalArgumentException("Resta inválida.");
					}
					valtotal -= val1; 
				}else {
					valtotal += val1;
				}
			}else {
				valtotal += val1;
			}
		}
		return valtotal;
	}
	
	public static void ComparadorRomano(String num1, String num2) {
		int val1 = TraductorRomano(num1);
		int val2 = TraductorRomano(num2);
		
		if (val1 > val2) {
			System.out.println(num1 + " con valor: " + val1 + " es mayor que "
			+ num2 + " con valor " + val2);
		}else if (val1 < val2) {
			System.out.println(num1 + " con valor: " + val1 + " es menor que "
			+ num2 + " con valor " + val2);
		}else {
			System.out.println("Ambos números son iguales al poseer el mismo valor: " + val1);
		}
	}
}
